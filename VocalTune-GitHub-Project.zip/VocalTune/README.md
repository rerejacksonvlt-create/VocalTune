# VocalTune

VocalTune is an experimental monophonic vocal pitch-correction VST3 built with C++ and JUCE.

## Current implementation

- VST3 and Standalone plugin targets.
- Real-time monophonic pitch detection using a YIN-style difference function.
- Chromatic and selected major/minor scale quantisation.
- Correction strength, response speed and maximum correction range controls.
- Lightweight dual-read-head delay pitch shifter.
- Live detected-frequency and note display.
- Parameter state save/restore.
- GitHub Actions workflow for Windows x64 builds.

## Important scope note

This repository is the **first working foundation**, not yet a NewTone-equivalent offline note editor. It currently processes live/streamed monophonic input. It does not yet include drag-and-drop audio-file editing, note blobs, waveform segmentation, per-note editing, MIDI export, harmony lanes or transparent high-quality offline rendering.

The current delay-line shifter is a prototype and can produce audible modulation/phasiness. It is not intended to match the sound quality of a mature phase-vocoder or spectral pitch-shifting engine. The next development milestone should replace it with a high-quality pitch/time-stretch engine and add an offline clip editor.

## Build on Windows locally

Requirements:
- Windows 10/11 x64
- Visual Studio 2022 with **Desktop development with C++**
- CMake 3.22+
- Git
- Internet access on the first configure (CMake downloads JUCE)

From a Developer PowerShell:

```powershell
git clone https://github.com/YOUR-USERNAME/VocalTune.git
cd VocalTune
cmake -S . -B build -A x64
cmake --build build --config Release --target VocalTune_VST3
```

The expected plugin output is:

```text
build/VocalTune_artefacts/Release/VST3/VocalTune.vst3
```

## Build using GitHub Actions

1. Create a GitHub repository named `VocalTune`.
2. Upload/push this project to the repository's `main` branch.
3. Open **Actions**.
4. Enable workflows if GitHub asks.
5. Select **Build VocalTune (Windows VST3)**.
6. Select **Run workflow**.
7. When the job completes, download the `VocalTune-Windows-VST3` artifact.

## Install in FL Studio

Copy the resulting `VocalTune.vst3` bundle to:

```text
C:\\Program Files\\Common Files\\VST3\\
```

Then open FL Studio's Plugin Manager and scan for plugins. If FL Studio does not detect it, confirm the build completed successfully and that the `.vst3` bundle contains its Windows x64 module.

## Notes

- This project uses JUCE under its applicable JUCE licence. Review JUCE's current licensing terms before distributing a commercial product.
- The VST3 SDK is obtained through JUCE's supported build setup. Review Steinberg's current VST3 licensing terms before distribution.
- Do not distribute third-party SDK binaries without checking their licences.
