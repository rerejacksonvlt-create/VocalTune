#include "PitchDetector.h"
#include <cmath>
#include <limits>

void PitchDetector::prepare(double sampleRate, int)
{
    currentSampleRate = sampleRate;
    reset();
}

void PitchDetector::reset()
{
    ring.fill(0.0f);
    writePosition = 0;
    samplesSinceAnalysis = 0;
    detectedFrequency = 0.0f;
    confidence = 0.0f;
}

float PitchDetector::processSample(float sample)
{
    ring[(size_t) writePosition] = sample;
    writePosition = (writePosition + 1) % windowSize;

    if (++samplesSinceAnalysis >= 256)
    {
        samplesSinceAnalysis = 0;
        analyse();
    }
    return detectedFrequency;
}

// YIN difference function with cumulative-mean normalisation.
// Intended for monophonic sources; polyphonic material is not reliably tracked.
void PitchDetector::analyse()
{
    constexpr int minLag = 35;
    constexpr int maxLag = 700;
    std::array<float, maxLag + 1> difference {};

    for (int lag = minLag; lag <= maxLag; ++lag)
    {
        double sum = 0.0;
        for (int i = 0; i < windowSize / 2; ++i)
        {
            const float a = ring[(size_t) ((writePosition + i) % windowSize)];
            const float b = ring[(size_t) ((writePosition + i + lag) % windowSize)];
            const double d = (double) a - (double) b;
            sum += d * d;
        }
        difference[(size_t) lag] = (float) sum;
    }

    double running = 0.0;
    for (int lag = 1; lag <= maxLag; ++lag)
    {
        running += difference[(size_t) lag];
        if (lag >= minLag && running > 1.0e-12)
            difference[(size_t) lag] *= (float) lag / (float) running;
    }

    int bestLag = -1;
    constexpr float threshold = 0.16f;
    for (int lag = minLag; lag <= maxLag; ++lag)
    {
        if (difference[(size_t) lag] < threshold)
        {
            while (lag + 1 <= maxLag && difference[(size_t) (lag + 1)] < difference[(size_t) lag])
                ++lag;
            bestLag = lag;
            break;
        }
    }

    if (bestLag < 0)
    {
        confidence = 0.0f;
        detectedFrequency = 0.0f;
        return;
    }

    // Parabolic interpolation improves frequency resolution between integer lags.
    float refinedLag = (float) bestLag;
    if (bestLag > minLag && bestLag < maxLag)
    {
        const float left = difference[(size_t) (bestLag - 1)];
        const float centre = difference[(size_t) bestLag];
        const float right = difference[(size_t) (bestLag + 1)];
        const float denominator = left - 2.0f * centre + right;
        if (std::abs(denominator) > 1.0e-9f)
            refinedLag += 0.5f * (left - right) / denominator;
    }

    confidence = juce::jlimit(0.0f, 1.0f, 1.0f - difference[(size_t) bestLag]);
    detectedFrequency = refinedLag > 0.0f
        ? (float) (currentSampleRate / refinedLag) : 0.0f;
}
