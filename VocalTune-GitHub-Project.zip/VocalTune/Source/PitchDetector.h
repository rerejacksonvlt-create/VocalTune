#pragma once
#include <JuceHeader.h>

class PitchDetector
{
public:
    void prepare(double sampleRate, int maximumBlockSize);
    void reset();
    float processSample(float sample);
    float getFrequency() const noexcept { return detectedFrequency; }
    float getConfidence() const noexcept { return confidence; }

private:
    static constexpr int windowSize = 2048;
    std::array<float, windowSize> ring {};
    int writePosition = 0;
    int samplesSinceAnalysis = 0;
    double currentSampleRate = 44100.0;
    float detectedFrequency = 0.0f;
    float confidence = 0.0f;

    void analyse();
};
