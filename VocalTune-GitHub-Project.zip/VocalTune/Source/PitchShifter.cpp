#include "PitchShifter.h"
#include <cmath>

void PitchShifter::prepare(double sampleRate, int channels)
{
    sr = sampleRate;
    delayLength = juce::jmax(4096, (int) (sr * 0.12));
    delay.assign((size_t) juce::jmax(1, channels),
                 std::vector<float>((size_t) delayLength, 0.0f));
    reset();
}

void PitchShifter::reset()
{
    for (auto& channel : delay)
        std::fill(channel.begin(), channel.end(), 0.0f);
    write = 0;
    phase = 0.0f;
    ratio = 1.0f;
}

void PitchShifter::setSemitones(float semitones) noexcept
{
    ratio = std::pow(2.0f, semitones / 12.0f);
}

float PitchShifter::readInterpolated(const std::vector<float>& data, float position) const
{
    while (position < 0.0f) position += (float) delayLength;
    while (position >= (float) delayLength) position -= (float) delayLength;
    const int i0 = (int) position;
    const int i1 = (i0 + 1) % delayLength;
    const float frac = position - (float) i0;
    return data[(size_t) i0] + frac * (data[(size_t) i1] - data[(size_t) i0]);
}

void PitchShifter::process(juce::AudioBuffer<float>& buffer)
{
    const int channels = juce::jmin(buffer.getNumChannels(), (int) delay.size());
    const float increment = (1.0f - ratio) / (float) juce::jmax(1, delayLength / 2);

    for (int n = 0; n < buffer.getNumSamples(); ++n)
    {
        const float p = phase;
        const float readA = (float) write - (float) delayLength * 0.75f
                            + p * (float) delayLength * 0.5f;
        const float readB = (float) write - (float) delayLength * 0.25f
                            + p * (float) delayLength * 0.5f;

        const float gainA = 0.5f - 0.5f * std::cos(juce::MathConstants<float>::twoPi * p);
        const float gainB = 1.0f - gainA;

        for (int ch = 0; ch < channels; ++ch)
        {
            auto& line = delay[(size_t) ch];
            const float input = buffer.getSample(ch, n);
            line[(size_t) write] = input;
            const float a = readInterpolated(line, readA);
            const float b = readInterpolated(line, readB);
            buffer.setSample(ch, n, a * gainA + b * gainB);
        }

        phase += increment;
        if (phase >= 1.0f) phase -= 1.0f;
        if (phase < 0.0f) phase += 1.0f;
        write = (write + 1) % delayLength;
    }
}
