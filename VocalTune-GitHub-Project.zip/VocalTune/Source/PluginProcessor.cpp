#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>

VocalTuneAudioProcessor::VocalTuneAudioProcessor()
    : AudioProcessor(BusesProperties()
        .withInput("Input", juce::AudioChannelSet::stereo(), true)
        .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      parameters(*this, nullptr, "PARAMETERS", createParameterLayout())
{
}

juce::AudioProcessorValueTreeState::ParameterLayout VocalTuneAudioProcessor::createParameterLayout()
{
    using namespace juce;
    std::vector<std::unique_ptr<RangedAudioParameter>> p;
    p.push_back(std::make_unique<AudioParameterFloat>("strength", "Correction Strength",
        NormalisableRange<float>(0.0f, 1.0f, 0.001f), 0.85f));
    p.push_back(std::make_unique<AudioParameterFloat>("speed", "Correction Speed",
        NormalisableRange<float>(5.0f, 100.0f, 0.1f), 35.0f));
    p.push_back(std::make_unique<AudioParameterFloat>("range", "Correction Range",
        NormalisableRange<float>(0.0f, 12.0f, 0.01f), 6.0f));
    p.push_back(std::make_unique<AudioParameterChoice>("scale", "Scale",
        StringArray { "Chromatic", "C Major", "G Major", "D Major", "A Major",
                      "E Major", "F Major", "Bb Major", "A Minor", "E Minor" }, 0));
    p.push_back(std::make_unique<AudioParameterBool>("bypass", "Bypass", false));
    return { p.begin(), p.end() };
}

void VocalTuneAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{
    detector.prepare(sampleRate, samplesPerBlock);
    shifter.prepare(sampleRate, getTotalNumOutputChannels());
    smoothedSemitones = 0.0f;
}

void VocalTuneAudioProcessor::releaseResources()
{
    detector.reset();
    shifter.reset();
}

bool VocalTuneAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto out = layouts.getMainOutputChannelSet();
    return out == juce::AudioChannelSet::mono() || out == juce::AudioChannelSet::stereo();
}

void VocalTuneAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    midi.clear();

    if (*parameters.getRawParameterValue("bypass") > 0.5f)
        return;

    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();
    if (channels == 0) return;

    const float strength = *parameters.getRawParameterValue("strength");
    const float speedMs = *parameters.getRawParameterValue("speed");
    const float range = *parameters.getRawParameterValue("range");
    const int scaleIndex = (int) *parameters.getRawParameterValue("scale");

    static constexpr bool major[7][12] = {
        { true,false,true,false,true,true,false,true,false,true,false,true }, // C
        { true,false,true,false,true,true,false,true,false,true,false,true }, // G (root offset applied below)
        { true,false,true,false,true,true,false,true,false,true,false,true },
        { true,false,true,false,true,true,false,true,false,true,false,true },
        { true,false,true,false,true,true,false,true,false,true,false,true },
        { true,false,true,false,true,true,false,true,false,true,false,true },
        { true,false,true,false,true,true,false,true,false,true,false,true }
    };
    const int roots[] = { 0, 0, 7, 2, 9, 4, 5, 10, 9, 4 };
    const bool minorScale = scaleIndex == 8 || scaleIndex == 9;
    const int root = roots[juce::jlimit(0, 9, scaleIndex)];
    const bool scaleNotes[12] = { true, false, true, false, true, true, false, true, false, true, false, true };
    const bool minorNotes[12] = { true, false, true, true, false, true, false, true, true, false, true, false };

    float monoFrequency = 0.0f;
    for (int n = 0; n < samples; ++n)
    {
        float mono = 0.0f;
        for (int ch = 0; ch < channels; ++ch)
            mono += buffer.getSample(ch, n);
        mono /= (float) channels;
        const float f = detector.processSample(mono);
        if (f > 40.0f && f < 1000.0f)
            monoFrequency = f;
    }

    if (monoFrequency > 0.0f)
    {
        const float midiNote = 69.0f + 12.0f * std::log2(monoFrequency / 440.0f);
        displayedFrequency.store(monoFrequency);
        displayedMidiNote.store(midiNote);
        int nearest = (int) std::round(midiNote);
        if (scaleIndex != 0)
        {
            float bestDistance = 1000.0f;
            int bestNote = nearest;
            for (int candidate = nearest - 6; candidate <= nearest + 6; ++candidate)
            {
                int pitchClass = (candidate - root + 120) % 12;
                const bool allowed = minorScale ? minorNotes[pitchClass] : scaleNotes[pitchClass];
                if (allowed && std::abs((float) candidate - midiNote) < bestDistance)
                {
                    bestDistance = std::abs((float) candidate - midiNote);
                    bestNote = candidate;
                }
            }
            nearest = bestNote;
        }
        float correction = ((float) nearest - midiNote) * strength;
        correction = juce::jlimit(-range, range, correction);
        const float smoothing = 1.0f - std::exp(-1.0f / (0.001f * speedMs * (float) getSampleRate()));
        smoothedSemitones += smoothing * (correction - smoothedSemitones);
        shifter.setSemitones(smoothedSemitones);
    }
    else
    {
        displayedFrequency.store(0.0f);
        displayedMidiNote.store(0.0f);
        smoothedSemitones *= 0.995f;
        shifter.setSemitones(smoothedSemitones);
    }

    shifter.process(buffer);
}

juce::AudioProcessorEditor* VocalTuneAudioProcessor::createEditor()
{
    return new VocalTuneAudioProcessorEditor(*this);
}

void VocalTuneAudioProcessor::getStateInformation(juce::MemoryBlock& dest)
{
    auto state = parameters.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, dest);
}

void VocalTuneAudioProcessor::setStateInformation(const void* data, int size)
{
    std::unique_ptr<juce::XmlElement> xml(getXmlFromBinary(data, size));
    if (xml != nullptr && xml->hasTagName(parameters.state.getType()))
        parameters.replaceState(juce::ValueTree::fromXml(*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new VocalTuneAudioProcessor();
}
