#pragma once
#include <JuceHeader.h>
#include "PitchDetector.h"
#include "PitchShifter.h"

class VocalTuneAudioProcessor : public juce::AudioProcessor
{
public:
    VocalTuneAudioProcessor();
    ~VocalTuneAudioProcessor() override = default;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return true; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.1; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;
    bool isBusesLayoutSupported(const BusesLayout&) const override;

    juce::AudioProcessorValueTreeState parameters;
    float getDetectedFrequency() const noexcept { return displayedFrequency.load(); }
    float getDetectedMidiNote() const noexcept { return displayedMidiNote.load(); }

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    PitchDetector detector;
    PitchShifter shifter;
    std::atomic<float> displayedFrequency { 0.0f };
    std::atomic<float> displayedMidiNote { 0.0f };
    float smoothedSemitones = 0.0f;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VocalTuneAudioProcessor)
};
