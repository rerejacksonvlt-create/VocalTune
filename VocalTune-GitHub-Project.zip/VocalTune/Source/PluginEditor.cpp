#include "PluginEditor.h"
#include <cmath>

VocalTuneAudioProcessorEditor::VocalTuneAudioProcessorEditor(VocalTuneAudioProcessor& p)
    : AudioProcessorEditor(&p), processor(p)
{
    setSize(760, 480);
    title.setText("VOCALTUNE", juce::dontSendNotification);
    title.setFont(juce::Font(27.0f, juce::Font::bold));
    title.setColour(juce::Label::textColourId, juce::Colour(0xfff2f4f8));
    addAndMakeVisible(title);

    auto setupSlider = [this](juce::Slider& s, const juce::String& suffix)
    {
        s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        s.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 22);
        s.setTextValueSuffix(suffix);
        s.setColour(juce::Slider::rotarySliderFillColourId, juce::Colour(0xff48d6b0));
        s.setColour(juce::Slider::thumbColourId, juce::Colour(0xfff2f4f8));
        addAndMakeVisible(s);
    };
    setupSlider(strength, "%");
    setupSlider(speed, " ms");
    setupSlider(range, " st");

    scale.addItemList({ "Chromatic", "C Major", "G Major", "D Major", "A Major",
                        "E Major", "F Major", "Bb Major", "A Minor", "E Minor" }, 1);
    addAndMakeVisible(scale);
    bypass.setButtonText("Bypass");
    addAndMakeVisible(bypass);

    auto setupLabel = [this](juce::Label& l, const juce::String& text)
    {
        l.setText(text, juce::dontSendNotification);
        l.setJustificationType(juce::Justification::centred);
        l.setColour(juce::Label::textColourId, juce::Colour(0xffc4ccd8));
        addAndMakeVisible(l);
    };
    setupLabel(strengthLabel, "CORRECTION");
    setupLabel(speedLabel, "SPEED");
    setupLabel(rangeLabel, "MAX RANGE");
    setupLabel(scaleLabel, "KEY / SCALE");
    setupLabel(frequencyLabel, "Detected frequency: --");
    setupLabel(noteLabel, "Detected note: --");

    auto& state = processor.parameters;
    strengthAttachment = std::make_unique<SliderAttachment>(state, "strength", strength);
    speedAttachment = std::make_unique<SliderAttachment>(state, "speed", speed);
    rangeAttachment = std::make_unique<SliderAttachment>(state, "range", range);
    scaleAttachment = std::make_unique<ComboAttachment>(state, "scale", scale);
    bypassAttachment = std::make_unique<ButtonAttachment>(state, "bypass", bypass);
    startTimerHz(12);
}

void VocalTuneAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour(0xff10151d));
    g.setColour(juce::Colour(0xff1b2532));
    g.fillRoundedRectangle(22.0f, 82.0f, 716.0f, 150.0f, 12.0f);
    g.setColour(juce::Colour(0xff48d6b0));
    g.fillRoundedRectangle(22.0f, 82.0f, 5.0f, 150.0f, 2.0f);
    g.setColour(juce::Colour(0xff7e8b9d));
    g.setFont(13.0f);
    g.drawText("LIVE PITCH MONITOR", 44, 96, 240, 20, juce::Justification::left);
    g.setColour(juce::Colour(0xff253243));
    for (int i = 0; i < 12; ++i)
        g.drawVerticalLine(50 + i * 56, 132.0f, 206.0f);
    g.setColour(juce::Colour(0xff48d6b0));
    g.drawLine(48.0f, 170.0f, 710.0f, 170.0f, 1.2f);
    g.setColour(juce::Colour(0xff7e8b9d));
    g.setFont(12.0f);
    g.drawText("MONOPHONIC INPUT  •  REAL-TIME CORRECTION", 44, 208, 500, 16);
    g.setColour(juce::Colour(0xff263342));
    g.drawRoundedRectangle(22.0f, 255.0f, 716.0f, 190.0f, 12.0f, 1.0f);
}

void VocalTuneAudioProcessorEditor::resized()
{
    title.setBounds(28, 20, 300, 45);
    frequencyLabel.setBounds(44, 130, 300, 28);
    noteLabel.setBounds(390, 130, 300, 28);
    strengthLabel.setBounds(50, 270, 140, 24);
    speedLabel.setBounds(220, 270, 140, 24);
    rangeLabel.setBounds(390, 270, 140, 24);
    scaleLabel.setBounds(555, 270, 170, 24);
    strength.setBounds(50, 295, 140, 125);
    speed.setBounds(220, 295, 140, 125);
    range.setBounds(390, 295, 140, 125);
    scale.setBounds(560, 310, 160, 30);
    bypass.setBounds(620, 25, 100, 30);
}

void VocalTuneAudioProcessorEditor::timerCallback()
{
    const float frequency = processor.getDetectedFrequency();
    const float midi = processor.getDetectedMidiNote();
    if (frequency > 0.0f)
    {
        const int note = (int) std::round(midi);
        static const char* names[] = { "C", "C#", "D", "D#", "E", "F",
                                       "F#", "G", "G#", "A", "A#", "B" };
        const int octave = note / 12 - 1;
        noteLabel.setText("Detected note: " + juce::String(names[(note % 12 + 12) % 12])
                          + juce::String(octave), juce::dontSendNotification);
        frequencyLabel.setText("Detected frequency: " + juce::String(frequency, 1) + " Hz",
                               juce::dontSendNotification);
    }
    else
    {
        noteLabel.setText("Detected note: --", juce::dontSendNotification);
        frequencyLabel.setText("Detected frequency: --", juce::dontSendNotification);
    }
}
