#pragma once
#include <JuceHeader.h>

// Lightweight dual-read-head delay-line pitch shifter.
// This is a practical prototype, not a transparent studio-grade phase-vocoder.
class PitchShifter
{
public:
    void prepare(double sampleRate, int channels);
    void reset();
    void setSemitones(float semitones) noexcept;
    void process(juce::AudioBuffer<float>& buffer);

private:
    double sr = 44100.0;
    float ratio = 1.0f;
    int write = 0;
    int delayLength = 4096;
    std::vector<std::vector<float>> delay;
    float phase = 0.0f;

    float readInterpolated(const std::vector<float>& data, float position) const;
};
