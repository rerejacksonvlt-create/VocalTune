#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class VocalTuneAudioProcessorEditor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit VocalTuneAudioProcessorEditor(VocalTuneAudioProcessor&);
    void paint(juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    VocalTuneAudioProcessor& processor;
    juce::Slider strength, speed, range;
    juce::ComboBox scale;
    juce::ToggleButton bypass;
    juce::Label title, frequencyLabel, noteLabel;
    juce::Label strengthLabel, speedLabel, rangeLabel, scaleLabel;
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ComboAttachment = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;
    std::unique_ptr<SliderAttachment> strengthAttachment, speedAttachment, rangeAttachment;
    std::unique_ptr<ComboAttachment> scaleAttachment;
    std::unique_ptr<ButtonAttachment> bypassAttachment;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VocalTuneAudioProcessorEditor)
};
